const ALLOWED = Object.freeze({
  partition: new Set(["note", "phone"]),
  full: new Set(["note", "phone"]),
  unit: new Set(["name", "type", "color"]),
});

const RENTAL_FIELDS = Object.freeze(new Set([
  "rent", "status", "tenant", "phone", "note", "deposit",
  "start_date", "end_date", "due_date", "contract_end", "cycle_anchor", "cycle_i",
  "rent_type", "elec_amount", "elec_paid", "lastRenewedKey",
]));

// Writable occupancy lifecycle only. "collected" / "partial" are financial outcomes —
// never set by operational status alone (that would mint visible محصّل without money).
const OCCUPANCY_STATUSES = Object.freeze(new Set(["vacant", "staff", "late", "pending", "expired"]));

const FORBIDDEN_FINANCIAL = Object.freeze(new Set([
  "paid_amount", "partial", "collectionMethod", "collectedBy", "collectedAt",
  "target", "remaining", "collected", "deposited", "cashLots", "transactions",
  "expenses", "ledger", "balances", "discount",
]));

/** Clear display residue when a space becomes vacant/staff. Does not create payments. */
function clearCollectionResidue(entity) {
  if (!entity || typeof entity !== "object") return;
  Object.assign(entity, {
    paid_amount: 0,
    partial: false,
    collectedBy: "",
    collectedAt: "",
    collectionMethod: "",
  });
}

/**
 * Preserve proven month paid_amount into a month-level bucket before clearing residue.
 * Prevents legacy KPI Actual Collected from vanishing on vacate when collectionEvents
 * do not exist. Never invents amounts — only copies existing paid_amount evidence.
 */
function preserveVacatedPaidEvidence(data, entity, fields) {
  if (!data || !entity || !fields) return;
  if (fields.status !== "vacant" && fields.status !== "staff") return;
  const paid = Number(entity.paid_amount || 0);
  if (!(paid > 0)) return;
  const amountFils = Math.round(paid * 100);
  if (!Number.isSafeInteger(amountFils) || amountFils <= 0) return;
  data.vacatedCollected = Array.isArray(data.vacatedCollected) ? data.vacatedCollected : [];
  data.vacatedCollected.push({
    amount: paid,
    amountFils,
    tenant: entity.tenant || "",
    preservedFrom: "paid_amount",
    at: new Date().toISOString(),
  });
}

/** Occupancy-only status for transfers (never collected/partial). */
function normalizeTransferOccupancyStatus(status) {
  const st = String(status || "");
  if (st === "collected" || st === "partial") return "late";
  if (OCCUPANCY_STATUSES.has(st)) return st;
  return "late";
}

function applyVacateResidueIfNeeded(data, entity, fields) {
  if (!fields || (fields.status !== "vacant" && fields.status !== "staff")) return;
  preserveVacatedPaidEvidence(data, entity, fields);
  clearCollectionResidue(entity);
}

const BUSINESS_REQUEST_TYPES = Object.freeze(new Set([
  "update_partition", "update_full", "transfer_tenant",
  "add_partition", "delete_partition", "add_unit", "delete_unit", "delete_full", "add_full_unit",
  // Employee daily booking must queue for Owner approval (no direct createDailyBooking).
  "add_daily",
]));

function cleanString(value, max) {
  if (typeof value !== "string") throw new Error("OPERATIONAL_VALUE_INVALID");
  const result = value.trim();
  if (result.length > max) throw new Error("OPERATIONAL_VALUE_TOO_LONG");
  return result;
}

function validatePatch(entityType, patch) {
  if (!patch || typeof patch !== "object" || Array.isArray(patch)) throw new Error("OPERATIONAL_PATCH_REQUIRED");
  const keys = Object.keys(patch);
  if (!keys.length) throw new Error("OPERATIONAL_PATCH_EMPTY");
  const allowed = ALLOWED[entityType];
  if (!allowed) throw new Error("OPERATIONAL_ENTITY_TYPE_INVALID");
  if (keys.some((key) => FORBIDDEN_FINANCIAL.has(key) || !allowed.has(key))) throw new Error("OPERATIONAL_FIELD_DENIED");
  const out = {};
  for (const key of keys) {
    if (key === "note") out[key] = cleanString(patch[key], 1000);
    else if (key === "phone") out[key] = cleanString(patch[key], 40);
    else if (key === "name") out[key] = cleanString(patch[key], 120);
    else if (key === "type") out[key] = cleanString(patch[key], 40);
    else if (key === "color") {
      if (typeof patch[key] !== "string" || !/^#[0-9a-fA-F]{6}$/.test(patch[key])) throw new Error("OPERATIONAL_COLOR_INVALID");
      out[key] = patch[key];
    }
  }
  return out;
}

/**
 * Accidental rent:0 wipe guard.
 * Legitimate rent:0 exists only for NEW vacant structure (add_partition / add_unit seed),
 * not as an update_partition/update_full patch on a live positive-rent occupancy.
 * Familiar vacate clears collection residue only — it does not zero rent.
 */
function assertRentPatchSafe(patch, entity) {
  if (!Object.prototype.hasOwnProperty.call(patch || {}, "rent")) return;
  const next = Number(patch.rent);
  const prev = Number(entity?.rent || 0);
  if (next === 0 && prev > 0) throw new Error("RENT_ZERO_WIPE_DENIED");
}

function validateRentalPatch(patch, entity = null) {
  if (!patch || typeof patch !== "object" || Array.isArray(patch)) throw new Error("OPERATIONAL_PATCH_REQUIRED");
  const keys = Object.keys(patch);
  if (!keys.length) throw new Error("OPERATIONAL_PATCH_EMPTY");
  if (keys.some((key) => FORBIDDEN_FINANCIAL.has(key) || !RENTAL_FIELDS.has(key))) throw new Error("OPERATIONAL_FIELD_DENIED");
  const out = {};
  for (const key of keys) {
    const value = patch[key];
    if (key === "status") {
      const st = String(value || "");
      // Visible محصّل / جزئي require financial evidence — never operational status alone.
      if (st === "collected" || st === "partial") throw new Error("COLLECTION_REQUIRES_FINANCIAL_COMMAND");
      if (!OCCUPANCY_STATUSES.has(st)) throw new Error("OCCUPANCY_STATUS_INVALID");
      out[key] = st;
    } else if (key === "rent" || key === "deposit" || key === "elec_amount") {
      const n = Number(value);
      if (!Number.isFinite(n) || n < 0) throw new Error("OPERATIONAL_VALUE_INVALID");
      out[key] = n;
    } else if (key === "elec_paid") {
      out[key] = !!value;
    } else if (key === "cycle_i") {
      const n = Number(value);
      if (!Number.isInteger(n) || n < 0) throw new Error("OPERATIONAL_VALUE_INVALID");
      out[key] = n;
    } else if (typeof value === "string") {
      out[key] = cleanString(value, key === "note" ? 1000 : 200);
    } else if (value == null) {
      out[key] = "";
    } else {
      throw new Error("OPERATIONAL_VALUE_INVALID");
    }
  }
  assertRentPatchSafe(out, entity);
  return out;
}

function locate(data, target) {
  if (target.entityType === "full") {
    const entity = (data.full || []).find((item) => String(item.id) === String(target.entityId));
    if (!entity) throw new Error("OPERATIONAL_ENTITY_NOT_FOUND");
    return entity;
  }
  const unit = (data.units || []).find((item) => String(item.id) === String(target.unitId || target.entityId));
  if (!unit) throw new Error("OPERATIONAL_ENTITY_NOT_FOUND");
  if (target.entityType === "unit") return unit;
  const entity = (unit.partitions || []).find((item) => String(item.id) === String(target.entityId));
  if (!entity) throw new Error("OPERATIONAL_ENTITY_NOT_FOUND");
  return entity;
}

export function applyOperationalPatch(monthDocument, payload, actor) {
  if (!actor || !["owner", "manager"].includes(actor.role)) throw new Error("MANAGER_REQUIRED");
  const target = payload?.target || {};
  const patch = validatePatch(String(target.entityType || ""), payload?.patch);
  const data = structuredClone(monthDocument?.data || {});
  const entity = locate(data, target);
  const currentVersion = Number(entity.operationalVersion ?? entity.version ?? 0);
  if (!Number.isInteger(payload.baseVersion) || payload.baseVersion !== currentVersion) throw new Error("STALE_OPERATIONAL_ENTITY");
  const before = Object.fromEntries(Object.keys(patch).map((key) => [key, entity[key] ?? null]));
  Object.assign(entity, patch, { operationalVersion: currentVersion + 1 });
  return { data, before, after: patch, version: currentVersion + 1, target };
}

export function applyOwnerRentalPatch(monthDocument, payload, actor) {
  if (!actor || !["owner", "manager"].includes(actor.role)) throw new Error("MANAGER_REQUIRED");
  const target = payload?.target || {};
  const entityType = String(target.entityType || "");
  if (!["partition", "full"].includes(entityType)) throw new Error("OPERATIONAL_ENTITY_TYPE_INVALID");
  const data = structuredClone(monthDocument?.data || {});
  const entity = locate(data, { ...target, entityType });
  const patch = validateRentalPatch(payload?.patch, entity);
  const currentVersion = Number(entity.operationalVersion ?? entity.version ?? 0);
  if (payload.baseVersion != null && Number(payload.baseVersion) !== currentVersion) throw new Error("STALE_OPERATIONAL_ENTITY");
  const before = Object.fromEntries(Object.keys(patch).map((key) => [key, entity[key] ?? null]));
  Object.assign(entity, patch, {
    operationalVersion: currentVersion + 1,
    version: Number(entity.version || 0) + 1,
  });
  applyVacateResidueIfNeeded(data, entity, patch);
  return { data, before, after: patch, version: currentVersion + 1, target: { ...target, entityType }, financialEffectFils: 0 };
}

/** Drop UI/ephemeral keys; still hard-deny financial mint fields. */
function rentalFieldsFromRequest(fields) {
  const raw = fields && typeof fields === "object" && !Array.isArray(fields) ? fields : {};
  const cleaned = {};
  for (const key of Object.keys(raw)) {
    if (FORBIDDEN_FINANCIAL.has(key)) throw new Error("OPERATIONAL_FIELD_DENIED");
    if (key.startsWith("_")) continue;
    if (!RENTAL_FIELDS.has(key)) continue;
    cleaned[key] = raw[key];
  }
  return cleaned;
}

function applyBusinessPayloadToMonth(data, type, payload) {
  if (type === "update_partition") {
    const unit = (data.units || []).find((u) => String(u.id) === String(payload.unitId));
    if (!unit) throw new Error("OPERATIONAL_ENTITY_NOT_FOUND");
    const part = (unit.partitions || []).find((p) => String(p.id) === String(payload.partId));
    if (!part) throw new Error("OPERATIONAL_ENTITY_NOT_FOUND");
    // Stale guard: employee captured baseVersion at send time; refuse silent overwrite.
    if (payload.baseVersion != null) {
      const currentVersion = Number(part.version || 0);
      if (Number(payload.baseVersion) !== currentVersion) throw new Error("STALE_OPERATIONAL_ENTITY");
    }
    const fields = validateRentalPatch(rentalFieldsFromRequest(payload.fields || {}), part);
    Object.assign(part, fields, { version: Number(part.version || 0) + 1, operationalVersion: Number(part.operationalVersion || 0) + 1 });
    applyVacateResidueIfNeeded(data, part, fields);
    return { target: { entityType: "partition", unitId: unit.id, entityId: part.id } };
  }
  if (type === "update_full") {
    const unit = (data.full || []).find((u) => String(u.id) === String(payload.unitId));
    if (!unit) throw new Error("OPERATIONAL_ENTITY_NOT_FOUND");
    if (payload.baseVersion != null) {
      const currentVersion = Number(unit.version || 0);
      if (Number(payload.baseVersion) !== currentVersion) throw new Error("STALE_OPERATIONAL_ENTITY");
    }
    const fields = validateRentalPatch(rentalFieldsFromRequest(payload.fields || {}), unit);
    Object.assign(unit, fields, { version: Number(unit.version || 0) + 1, operationalVersion: Number(unit.operationalVersion || 0) + 1 });
    applyVacateResidueIfNeeded(data, unit, fields);
    return { target: { entityType: "full", entityId: unit.id } };
  }
  if (type === "add_partition") {
    const unit = (data.units || []).find((u) => String(u.id) === String(payload.unitId));
    if (!unit) throw new Error("OPERATIONAL_ENTITY_NOT_FOUND");
    const part = payload.part;
    if (!part || part.id == null) throw new Error("OPERATIONAL_VALUE_INVALID");
    if ((unit.partitions || []).some((p) => String(p.id) === String(part.id))) throw new Error("PARTITION_EXISTS");
    unit.partitions = unit.partitions || [];
    unit.partitions.push({ ...part, status: part.status || "vacant", version: 0, operationalVersion: 0 });
    return { target: { entityType: "partition", unitId: unit.id, entityId: part.id } };
  }
  if (type === "delete_partition") {
    const unit = (data.units || []).find((u) => String(u.id) === String(payload.unitId));
    if (!unit) throw new Error("OPERATIONAL_ENTITY_NOT_FOUND");
    const idx = (unit.partitions || []).findIndex((p) => String(p.id) === String(payload.partId));
    if (idx < 0) throw new Error("OPERATIONAL_ENTITY_NOT_FOUND");
    unit.partitions.splice(idx, 1);
    return { target: { entityType: "partition", unitId: unit.id, entityId: payload.partId } };
  }
  if (type === "add_unit") {
    const unit = payload.unit;
    if (!unit || unit.id == null) throw new Error("OPERATIONAL_VALUE_INVALID");
    data.units = data.units || [];
    if (data.units.some((u) => String(u.id) === String(unit.id))) throw new Error("UNIT_EXISTS");
    data.units.push(unit);
    return { target: { entityType: "unit", entityId: unit.id } };
  }
  if (type === "add_full_unit") {
    const unit = payload.unit;
    if (!unit || unit.id == null) throw new Error("OPERATIONAL_VALUE_INVALID");
    data.full = data.full || [];
    if (data.full.some((u) => String(u.id) === String(unit.id))) throw new Error("UNIT_EXISTS");
    data.full.push(unit);
    return { target: { entityType: "full", entityId: unit.id } };
  }
  if (type === "delete_unit") {
    const idx = (data.units || []).findIndex((u) => String(u.id) === String(payload.unitId));
    if (idx < 0) throw new Error("OPERATIONAL_ENTITY_NOT_FOUND");
    data.units.splice(idx, 1);
    return { target: { entityType: "unit", entityId: payload.unitId } };
  }
  if (type === "delete_full") {
    const idx = (data.full || []).findIndex((u) => String(u.id) === String(payload.unitId));
    if (idx < 0) throw new Error("OPERATIONAL_ENTITY_NOT_FOUND");
    data.full.splice(idx, 1);
    return { target: { entityType: "full", entityId: payload.unitId } };
  }
  if (type === "add_daily") {
    // Mirror approved daily booking into the familiar month document for UI lists/KPIs.
    // Canonical cash/bank effect is applied separately by createDailyBooking on approve.
    const booking = payload.booking && typeof payload.booking === "object" ? { ...payload.booking } : null;
    if (!booking) throw new Error("OPERATIONAL_VALUE_INVALID");
    const bookingId = String(payload.requestId || booking.id || "").trim();
    if (!bookingId) throw new Error("OPERATIONAL_VALUE_INVALID");
    data.dailyBookings = data.dailyBookings || [];
    if (!data.dailyBookings.some((b) => String(b.id) === bookingId || String(b.requestId) === bookingId)) {
      data.dailyBookings.push({
        ...booking,
        id: bookingId,
        requestId: bookingId,
        status: booking.status || "paid",
      });
    }
    return { target: { entityType: "daily", entityId: bookingId } };
  }
  if (type === "transfer_tenant") {
    const srcUnit = (data.units || []).find((u) => String(u.id) === String(payload.fromUnitId));
    const dstUnit = (data.units || []).find((u) => String(u.id) === String(payload.toUnitId));
    if (!srcUnit || !dstUnit) throw new Error("OPERATIONAL_ENTITY_NOT_FOUND");
    const src = (srcUnit.partitions || []).find((p) => String(p.id) === String(payload.fromPartId));
    const dst = (dstUnit.partitions || []).find((p) => String(p.id) === String(payload.toPartId));
    if (!src || !dst) throw new Error("OPERATIONAL_ENTITY_NOT_FOUND");
    if (!["vacant", "staff"].includes(String(dst.status || ""))) throw new Error("TARGET_OCCUPIED");
    if (payload.fields && Object.prototype.hasOwnProperty.call(payload.fields, "status")) {
      const requested = String(payload.fields.status || "");
      if (requested === "collected" || requested === "partial") throw new Error("COLLECTION_REQUIRES_FINANCIAL_COMMAND");
    }
    for (const key of Object.keys(payload.fields || {})) {
      if (FORBIDDEN_FINANCIAL.has(key)) throw new Error("OPERATIONAL_FIELD_DENIED");
    }
    // Occupancy + contract fields only — never paid_amount / collected* / partial.
    const moveKeys = ["tenant", "phone", "deposit", "note", "start_date", "due_date", "contract_end", "status", "rent", "elec_paid", "elec_amount", "lastRenewedKey"];
    for (const key of moveKeys) {
      let value;
      if (payload.fields && Object.prototype.hasOwnProperty.call(payload.fields, key)) value = payload.fields[key];
      else if (src[key] !== undefined) value = src[key];
      else continue;
      if (key === "status") value = normalizeTransferOccupancyStatus(value);
      dst[key] = value;
    }
    dst.status = normalizeTransferOccupancyStatus(dst.status);
    clearCollectionResidue(dst);
    // Preserve proven source paid_amount for month KPI before vacating source residue.
    preserveVacatedPaidEvidence(data, src, { status: "vacant" });
    Object.assign(src, { tenant: "", phone: "", status: "vacant", note: "" });
    clearCollectionResidue(src);
    return { target: { entityType: "partition", unitId: dstUnit.id, entityId: dst.id } };
  }
  throw new Error("REQUEST_TYPE_UNSUPPORTED");
}

export function applyApprovedBusinessRequest(monthDocument, request, actor) {
  if (!actor || !["owner", "manager"].includes(actor.role)) throw new Error("MANAGER_REQUIRED");
  const type = String(request.type || "");
  if (!BUSINESS_REQUEST_TYPES.has(type)) throw new Error("REQUEST_TYPE_UNSUPPORTED");
  const data = structuredClone(monthDocument?.data || {});
  const payload = { ...(request.payload || {}) };
  // Ensure approve path can idempotently key month.dailyBookings by request id.
  if (request.id != null && payload.requestId == null) payload.requestId = request.id;
  const applied = applyBusinessPayloadToMonth(data, type, payload);
  return { data, target: applied.target, financialEffectFils: 0 };
}

export function assertBusinessRequestType(type) {
  if (!BUSINESS_REQUEST_TYPES.has(String(type || ""))) throw new Error("REQUEST_TYPE_UNSUPPORTED");
  return String(type);
}

export const operationalAllowedFields = (entityType) => [...(ALLOWED[entityType] || [])];
export const businessRequestTypes = [...BUSINESS_REQUEST_TYPES];
